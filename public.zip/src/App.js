import './App.css';
import React, {useState, useEffect} from 'react';


import RegistrationForm from "./Registrationform";

const App = () => {
  return (
    <div>
      <RegistrationForm />
    </div>
  );
};

export default App;

